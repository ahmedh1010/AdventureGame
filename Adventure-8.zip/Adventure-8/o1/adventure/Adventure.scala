package o1.adventure


/** The class `Adventure` represents text adventure games. An adventure consists of a player and 
  * a number of areas that make up the game world. It provides methods for playing the game one
  * turn at a time and for checking the state of the game.
  *
  * N.B. This version of the class has a lot of "hard-coded" information which pertain to a very 
  * specific adventure game that involves a small trip through a twisted forest. All newly created 
  * instances of class `Adventure` are identical to each other. To create other kinds of adventure 
  * games, you will need to modify or replace the source code of this class. */
class Adventure {

  /** The title of the adventure game. */
  val title = "A Journey through Morning"
    
  private val denial      = new Area("Bedroom", "You cannot believe this, all this work for vain. \nYou are in the nile. \nHow do you deal with this? \nDo you: \nA: Repeatedly refresh the page hoping to change. \nB: Pretend you got accepted and go the university anyways.")
  private val anger       = new Area("Hell", "All you see is red. The heat scorches you but you don't seem to notice.\nYou are angry")
  private val bargaining  = new Area("Purgatory", "You are in the purgatory, bargaining your way out of this situation. How do you get out? \n A: You email the uni asking them to reconsider. \n B: Spend the rest of the week thinking of 'if only...' scenarios")
  private val depression  = new Area("Under Water", "You are stuck under a sheet of ice in a lake. The cold has become part of you. \nYou are depressed. \nDo you: \nA: Play a game of roulette. \nB: Play a different kind of roulette \nTo do A type 'roulette' followed by a number from 0 to 36. To do B type 'shoot' followed by some number from 1 to 6. To move on, type 'move on'")
  private val acceptance  = new Area("Bedroom", "You are nearing the end of your journey, do you wish to accept your fate?")
  private val aalto       = new Area("Aalto", "You have accepted your fate, choosing to go you second favourite school: Aalto. Maybe life isn't so bad after all.")
  private val destination = aalto    

       denial.setNeighbors(Vector("north" -> anger)) //, "east" -> tangle, "south" -> southForest, "west" -> clearing   ))
        anger.setNeighbors(Vector("north" -> bargaining, "south" -> denial)) //                        "east" -> tangle, "south" -> middle,      "west" -> clearing   ))
   bargaining.setNeighbors(Vector("north" -> depression, "south" -> anger)) //      "east" -> tangle, "south" -> southForest, "west" -> clearing   ))
   depression.setNeighbors(Vector("north" -> acceptance, "south" -> bargaining)) // "east" -> middle, "south" -> southForest, "west" -> northForest))
   acceptance.setNeighbors(Vector("north" -> aalto,      "south" -> depression )) // "east" -> home,   "south" -> southForest, "west" -> northForest))
        aalto.setNeighbors(Vector(                       "south" -> acceptance))

  anger.addItem(new Item("phone", "It's a nice phone, suitable for throwing."))
  //southForest.addItem(new Item("remote", "It's the remote control for your TV.\nWhat it was doing in the forest, you have no idea.\nProblem is, there's no battery."))

  /** The character who is the protagonist of the adventure and whom the real-life player controls. */
  val player = new Player(denial)

  /** The number of turns that have passed since the start of the game. */
  var turnCount = 0
  /** The maximum number of turns that this adventure game allows before time runs out. */
  val timeLimit = 40 

 
  /** Determines if the adventure is complete, that is, if the player has won. */
  def isComplete = this.player.location == this.destination

  /** Determines whether the player has won, lost, or quit, thereby ending the game. */ 
  def isOver = this.isComplete || this.player.hasQuit || this.turnCount == this.timeLimit || !this.player.isAlive || this.player.isShot

  /** Returns a message that is to be displayed to the player at the beginning of the game. */
  def welcomeMessage = "You are nervously checking your dream university application. 'Rejected' it reads. \nYou are devastaded, but you can pull through this, right?"

    
  /** Returns a message that is to be displayed to the player at the end of the game. The message 
    * will be different depending on whether or not the player has completed their quest. */
  def goodbyeMessage = {
    if (this.isComplete) 
      "You've survived through the mourning, good job."
    else if (!player.isAlive) 
      "Oops! You made the unhealthy choice too often. Play again, and be mindful of how you deal with stress. \nGame over!"
    else if (this.turnCount == this.timeLimit)
      "Oh no! Time's up. Starved of entertainment, you collapse and weep like a child.\nGame over!"
    else if(this.player.isShot)
      "Ouch, that hurt... Try playing a less Russian game of roulette next time"
    else // game over due to player quitting
      "Quitter!" 
  }

  
  /** Plays a turn by executing the given in-game command, such as "go west". Returns a textual 
    * report of what happened, or an error message if the command was unknown. In the latter 
    * case, no turns elapse. */
  def playTurn(command: String): String = {
    val action = new Action(command)
    val outcomeReport = action.execute(this.player)
    if (outcomeReport.isDefined) { 
      this.turnCount += 1 
    }
    outcomeReport.getOrElse("Unknown command: \"" + command + "\".")
  }
  
  
}


  