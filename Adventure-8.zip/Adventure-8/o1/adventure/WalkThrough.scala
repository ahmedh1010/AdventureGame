/**The objective of our game is to go through the mental states of when one finds out they were
rejected from their dream school. These are: denial, anger, bargaining, depression, and
acceptance. You begin the game with 3 “hitPoints,” and each time you make a decision that isn’t
considered the “healthy choice,” you lose one hitPoint.

Keep in mind that at any point in the game, you can type the word “help” and a list of available
words to use will pop up.

The first stage, denial. The student is in denial of his/her rejection, so (s)he must decide how to
react to said rejection. They have a choice between continuously refreshing the website,
pretending they didn’t get rejected. To choose the former, you would have to type “do a” and
for the latter, “do b.” (these instructions can be find by typing “help,” as mentioned above)

The second stage, anger. This stage allows you to pick up our item, which is a phone. You have
two options: throw your phone and shatter it, or call your mom.

The third stage, is bargaining. The player has the choice between emailing the school asking
them to reconsider their decision, or continuously wonder about multiple ‘if’ statements
throughout the week.

The fourth stage is depression, where the player has the choices between playing regular
roulette or the much more dangerous kind.

The final stage is that of acceptance. In this state the player only has two choices; to accept
their fate or not. After you have accepted your fate, you will find yourself at Aalto University. If
you choose not to accept, you die, and the game is over '.

As for the map, seems rather unessecary since our game is a 5 stage linear map. So we'll leave that to 
the reader.
* */
