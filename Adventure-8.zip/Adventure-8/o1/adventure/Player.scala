package o1.adventure

import scala.collection.mutable.Map

  
/** A `Player` object represents a player character controlled by the real-life user of the program. 
  *
  * A player object's state is mutable: the player's location and possessions can change, for instance.
  *
  * @param startingArea  the initial location of the player */
class Player(startingArea: Area) {

  private var currentLocation = startingArea        // gatherer: changes in relation to the previous location
  private var quitCommandGiven = false              // one-way flag
  private val possessions = Map[String, Item]()     // container of all the items that the player has
  private var hitPoints = 3
  private var alive = true
  private var shot = false
  
  def isShot = shot
  
  /** Determines if the player has indicated a desire to quit the game. */
  def hasQuit = this.quitCommandGiven

  
  /** Returns the current location of the player. */
  def location = this.currentLocation
  
  //Causes the player to take damage if s/he made the unhealthy choice
  def takeDamage() = {
    this.hitPoints-=1
    "Your mental health is not improving"
  }
  
    //Returns a Boolean of whether or not the player has ran out of hitpoints.
  
  def isAlive = (hitPoints >= 1)
    
  /** Attempts to move the player in the given direction. This is successful if there 
    * is an exit from the player's current location towards the direction name. 
    * Returns a description of the results of the attempt. */
  def go(direction: String) = {
    if (this.currentLocation.name != "Hell"){
    val destination = this.location.neighbor(direction)
    this.currentLocation = destination.getOrElse(this.currentLocation) 
    if (destination.isDefined) "You move to the next stage." else "You can't do that."
    }
    else "Try picking up the phone..."
  }
  
  /** Causes the player to rest for a short while (this has no substantial effect in game terms).
    * Returns a description of what happened. */
  def rest() = {
    "You rest for a while. You don't feel much better, but you need to face your problems one day..." 
  }
  
  /** Causes the player to throw the item.
    * Returns the result */
  def throwItem(itemName: String) = {
    this.drop(itemName)
    currentLocation.removeItem(itemName)
    this.hitPoints-=1
    this.currentLocation = this.location.neighbor("north").get
    "You have thrown the " + itemName + " across the room. It shatters into a million pieces."
  }
    
  /** Signals that the player wants to quit the game. Returns a description of what happened 
    * within the game as a result (which is the empty string, in this case). */
  def quit() = {
    this.quitCommandGiven = true
    ""
  }
  
  
  /** Returns a brief description of the player's state, for debugging purposes. */
  override def toString = "Now at: " + this.location.name   


  /** Tries to pick up an item of the given name. This is successful if such an item is 
    * located in the player's current location. If so, the item is added to the player's 
    * inventory. Returns a description of the results of the attempt. */
  def get(itemName: String) = {
    val received = this.location.removeItem(itemName)
    for (newItem <- received) {
      this.possessions.put(newItem.name, newItem)  
    }
    if (received.isDefined && itemName == "phone") "You picked up the phone, do you: \nCall mom: Call your mom and talk with her. \nThrow phone: Throw the phone in anger."
    else if (received.isDefined) "You pick up the " + itemName + "." else "There is no " + itemName + " here to pick up."
  } 
  // Does nothing practically. 
  def callMom()  = 
    if (this.has("phone")){
      this.currentLocation = this.location.neighbor("north").get
      "You chat with your mom. She calms down your anger. You have moved to the next stage, the purgatory."
    }
    else "You need a phone to make this action."
  /** Determines whether the player is carrying an item of the given name. */
  def has(itemName: String) = this.possessions.contains(itemName)
  
  
  /** Tries to drop an item of the given name. This is successful if such an item is 
    * currently in the player's possession. If so, the item is removed from the 
    * player's inventory. Returns a description of the results of the attempt. */
  def drop(itemName: String) = {
    val removed = this.possessions.remove(itemName) 
    for (oldItem <- removed) {
      this.location.addItem(oldItem)
    }
    if (removed.isDefined) "You drop the " + itemName + "." else "You don't have that!"  
  }

  
  /** Causes the player to examine the item of the given name. This is successful if such
    * an item is currently in the player's possession. Returns a description of the results 
    * of the attempt, including a description of the item, if successful. */
  def examine(itemName: String) = {
    def lookText(item: Item) = "You look closely at the " + item.name + ".\n" + item.description
    val failText = "If you want to examine something, you need to pick it up first."
    this.possessions.get(itemName).map(lookText).getOrElse(failText)
  }
  
  def roulette(number: Int) = {
    if(this.currentLocation.name == "Under Water"){
    if(scala.util.Random.nextInt(36) == number){
      hitPoints += 100
      "You chose the right number, you are on cloud nine. To play again, type 'roulette' followed by a number from 0 to 36"
    }
    else "You chose the wrong number, it hurts a little. To play again, type 'roulette' followed by a number from 0 to 36"
    takeDamage
    }
    else "Maybe you should find a roulette table"
  }
  /** Causes the player to list what they are carrying. Returns a listing of the player's 
    * possessions or a statement indicating that the player is carrying nothing. */
  def inventory = { 
    if (this.possessions.isEmpty) 
      "You are empty-handed." 
    else 
      "You are carrying:\n" + this.possessions.keys.mkString("\n")
  }
  
  def accept() = {
      this.currentLocation = this.location.neighbor("north").get
      "You have accepted your destiny"
  }
  def dontAccept () = {
    this.currentLocation = this.location.neighbor("north").get
    this.takeDamage()
  }
  def sendHelp() = {
   "if you would like to do something, please type 'do' and 'a' or 'b'\nif you would like to go back, type 'go back'\nif you would like to rest, type 'rest'\nif you would like to call mom, type 'call mom' but only if you are holding the phone \nif you would like to quit the game, type 'quit'\nif you would like to see your inventory, type 'inventory' \nif you would like to throw an item, type 'throw' + itemname"
  }

  def doB()= {
    this.takeDamage
    go("north")
  }
  def move()={ 
    if(this.currentLocation.name == "Under Water")go("north")
    else "You can't do that here."
  }
  def shoot (number: Int) = {
    if(this.currentLocation.name == "Under Water") {
      if(scala.util.Random.nextInt(6) == number-1) {
        shot = true
        "you shoot your shot, and it hits. Unfortunate ending."
      }
      else "you pull the trigger... its empty. To try again, type 'shoot' followed by a number from 1 to 6. Else, type 'move on' to move to the next stage"
     }
    else "nothing to shoot with here."
  }
  def doA() = {
    go("north")
  }
}



